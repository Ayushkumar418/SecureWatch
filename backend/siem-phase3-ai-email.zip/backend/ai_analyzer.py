"""
ai_analyzer.py — Sends SIEM alerts to Claude API (claude-sonnet-4-6)
                 and stores AI-generated threat explanations back in DB.

What it does:
  • Every 30 seconds, fetches unanalyzed alerts from DB
  • Sends alert details to Claude API
  • Gets plain-English explanation + severity reasoning + recommended action
  • Saves explanation back to alerts.ai_explanation column

Run:  python ai_analyzer.py
"""
import os
import time
import json
import logging
import anthropic
from dotenv import load_dotenv

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from models.db import get_conn

load_dotenv()

POLL_INTERVAL = 30   # seconds between DB checks

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [ai_analyzer] %(levelname)s %(message)s"
)
log = logging.getLogger("ai_analyzer")

client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

SYSTEM_PROMPT = """You are a senior cybersecurity analyst AI inside a SIEM system.
You analyze security alerts and explain them clearly to a junior security team.

For every alert you receive, respond ONLY with a valid JSON object — no preamble,
no markdown fences. Use this exact structure:

{
  "threat_summary": "1-2 sentence plain English explanation of what happened",
  "why_dangerous": "1 sentence explaining the risk if ignored",
  "attacker_intent": "brute_force | data_exfiltration | reconnaissance | privilege_escalation | web_attack | unknown",
  "confidence": "HIGH | MEDIUM | LOW",
  "recommended_action": "Specific step the team should take right now",
  "severity_reasoning": "1 sentence explaining why this severity level was assigned"
}"""


def build_user_prompt(alert: dict) -> str:
    return f"""Analyze this SIEM alert:

Rule:        {alert['rule_name']}
Severity:    {alert['severity']}
Title:       {alert['title']}
Description: {alert['description'] or 'N/A'}
IPs involved: {', '.join(alert['related_ips'] or []) or 'None'}
Users involved: {', '.join(alert['related_users'] or []) or 'None'}
Event count: {alert['event_count']}
Detected at: {alert['created_at']}"""


def analyze_alert(alert: dict) -> dict | None:
    """Call Claude API and return parsed JSON response."""
    try:
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=500,
            system=SYSTEM_PROMPT,
            messages=[
                {"role": "user", "content": build_user_prompt(alert)}
            ]
        )
        raw = message.content[0].text.strip()
        # Strip markdown fences if model adds them
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw.strip())

    except json.JSONDecodeError as e:
        log.error("JSON parse error for alert %s: %s", alert['id'], e)
        return None
    except anthropic.APIError as e:
        log.error("Claude API error: %s", e)
        return None


def format_explanation(analysis: dict) -> str:
    """Format Claude's JSON response into a readable string for the DB."""
    return (
        f"🔍 THREAT SUMMARY\n{analysis['threat_summary']}\n\n"
        f"⚠️  WHY DANGEROUS\n{analysis['why_dangerous']}\n\n"
        f"🎯 ATTACKER INTENT: {analysis['attacker_intent'].replace('_', ' ').title()}\n"
        f"📊 CONFIDENCE: {analysis['confidence']}\n\n"
        f"✅ RECOMMENDED ACTION\n{analysis['recommended_action']}\n\n"
        f"📝 SEVERITY REASONING\n{analysis['severity_reasoning']}"
    )


def fetch_unanalyzed_alerts() -> list[dict]:
    """Get alerts that don't have an AI explanation yet."""
    sql = """
        SELECT id, rule_name, severity, title, description,
               related_ips, related_users, event_count, created_at
        FROM   alerts
        WHERE  ai_explanation IS NULL
          AND  is_resolved = FALSE
        ORDER  BY created_at DESC
        LIMIT  10
    """
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            cols = [d[0] for d in cur.description]
            return [dict(zip(cols, row)) for row in cur.fetchall()]


def save_explanation(alert_id: int, explanation: str):
    """Write AI explanation back to the alerts table."""
    sql = "UPDATE alerts SET ai_explanation = %s WHERE id = %s"
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (explanation, alert_id))


def run():
    api_key = os.getenv("ANTHROPIC_API_KEY", "")
    if not api_key or api_key == "sk-ant-your-key-here":
        log.error("ANTHROPIC_API_KEY not set in .env — cannot start AI analyzer")
        return

    log.info("AI Analyzer started. Polling every %ds for new alerts.", POLL_INTERVAL)

    while True:
        alerts = fetch_unanalyzed_alerts()

        if alerts:
            log.info("Found %d unanalyzed alert(s). Sending to Claude...", len(alerts))
            for alert in alerts:
                log.info("  Analyzing alert #%s: %s", alert['id'], alert['title'])
                analysis = analyze_alert(alert)

                if analysis:
                    explanation = format_explanation(analysis)
                    save_explanation(alert['id'], explanation)
                    log.info("  ✅ Alert #%s analyzed — intent: %s, confidence: %s",
                             alert['id'], analysis['attacker_intent'], analysis['confidence'])
                else:
                    log.warning("  ⚠️  Alert #%s — analysis failed, will retry next cycle", alert['id'])

                time.sleep(1)   # small delay between API calls
        else:
            log.debug("No unanalyzed alerts found.")

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    run()
